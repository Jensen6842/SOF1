for b in range(5):
    print(b)